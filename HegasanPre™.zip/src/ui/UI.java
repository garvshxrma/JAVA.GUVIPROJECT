package ui;

import dao.UserDAO;
import model.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;

public class UI extends JFrame {
    private JTextField nameField, emailField;
    private JPasswordField passwordField;
    private JButton submitButton, viewUsersButton;
    private JTextArea usersArea;

    public UI() {
        setTitle("E-Marketing App");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField(20);

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);

        submitButton = new JButton("Register");
        viewUsersButton = new JButton("View Users");
        usersArea = new JTextArea(10, 40);
        usersArea.setEditable(false);

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0; gbc.gridy = 0;
        add(nameLabel, gbc);
        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(emailLabel, gbc);
        gbc.gridx = 1;
        add(emailField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(passwordLabel, gbc);
        gbc.gridx = 1;
        add(passwordField, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        add(submitButton, gbc);

        gbc.gridy = 4;
        add(viewUsersButton, gbc);

        gbc.gridy = 5;
        add(new JScrollPane(usersArea), gbc);

        submitButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.");
                return;
            }

            if (!email.contains("@") || !email.contains(".")) {
                JOptionPane.showMessageDialog(this, "Enter a valid email address.");
                return;
            }

            User user = new User(0, name, email, password);
            UserDAO dao = new UserDAO();
            try {
                dao.insertUser(user);
                JOptionPane.showMessageDialog(this, "User Registered!");
                nameField.setText(""); emailField.setText(""); passwordField.setText("");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        viewUsersButton.addActionListener(e -> {
            UserDAO dao = new UserDAO();
            try {
                List<User> users = dao.getAllUsers();
                StringBuilder sb = new StringBuilder();
                for (User user : users) {
                    sb.append("ID: ").append(user.getId()).append(", Name: ").append(user.getName())
                      .append(", Email: ").append(user.getEmail()).append("\n");
                }
                usersArea.setText(sb.toString());
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
    }
}