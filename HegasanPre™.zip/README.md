
# E-Marketing Java Application

## Overview
This is a simple desktop-based Java Swing application for user registration and viewing registered users using an underlying database. It follows the MVC architecture.

## Features Implemented
1. **Core Feature Implementation** – User can register with Name, Email, and Password. Registered users can be viewed.
2. **Error Handling and Robustness** – Includes try-catch blocks for handling SQL exceptions and input errors.
3. **Integration of Components** – UI integrates with DAO (Data Access Object) and Model layers.
4. **Event Handling and Processing** – ActionListeners used to respond to button clicks.
5. **Data Validation** – Basic field checks (e.g., empty fields) can be implemented/extended.
6. **Code Quality and Innovation** – Clean separation of concerns using packages (model, dao, ui). Uses GridBagLayout for GUI design.

## Technologies Used
- Java
- Swing (UI)
- JDBC (Database interaction)
- MySQL/SQLite (based on implementation in dao)

## How to Run
1. Open project in your preferred Java IDE (e.g., IntelliJ, Eclipse).
2. Set up the database as expected in the `dao` package (check `UserDAO.java`).
3. Compile and run `Main.java`.

## Grading Rubric Mapping
| Criteria                            | Marks |
|-------------------------------------|-------|
| Core Feature Implementation         | 5     |
| Error Handling and Robustness       | 5     |
| Integration of Components           | 5     |
| Event Handling and Processing       | 5     |
| Data Validation                     | 5     |
| Code Quality and Innovative Features| 3     |
| Project Documentation (this file)  | ✅     |

---
